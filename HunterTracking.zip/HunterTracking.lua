-- HunterTracking.lua v3.4
local TRACK = {
    ["Животное"]   = "Выслеживание животных",
    ["Гуманоид"]   = "Выслеживание гуманоидов",
    ["Нежить"]     = "Выслеживание нежити",
    ["Демон"]      = "Выслеживание демонов",
    ["Элементаль"] = "Выслеживание элементалей",
    ["Дракон"]     = "Выслеживание драконов",
    ["Великан"]    = "Выслеживание великанов",
    ["Скрытый"]    = "Выслеживание скрытого",
}

HunterTrackingDB = HunterTrackingDB or {}
if HunterTrackingDB.auto == nil then HunterTrackingDB.auto = false end

local auto = HunterTrackingDB.auto
local lastType, lastSpell = nil, nil

local ADDON_MSG = "|cffffd100HunterTracking|r |cffffffffby|r |cff33ff99SevenKDS|r |cff888888v3.4|r"

local function Say(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99HT|r " .. tostring(msg))
end

local function PrintLoad()
    DEFAULT_CHAT_FRAME:AddMessage(ADDON_MSG)
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99HT|r авто-трекинг: "
        .. (auto and "|cff00ff00ВКЛ|r" or "|cffff3333ВЫКЛ|r")
        .. "  |cff888888— /ht auto|r")
end

local function SetTracking(name)
    if type(CastSpellByName) ~= "function" or not name then return false end
    pcall(CastSpellByName, name)
    return true
end

local function TrackingStillOn(spell)
    if not spell or lastSpell ~= spell then return false end
    if type(GetTrackingInfo) == "function" then
        for i = 1, 16 do
            local ok, name, _, _, active = pcall(GetTrackingInfo, i)
            if ok and name and active then return name == spell end
        end
    end
    return true
end

local function IsDeadTarget()
    if UnitIsDead and UnitIsDead("target") then return true end
    if UnitIsGhost and UnitIsGhost("target") then return true end
    if UnitIsCorpse and UnitIsCorpse("target") then return true end
    return false
end

-- Цель не годится: нет цели, мёртвая, союзник, нельзя атаковать, игрок.
-- Нейтральные (жёлтые), но атакуемые мобы СЮДА НЕ попадают — их отслеживаем.
local function BadTarget()
    if not UnitExists("target") then return true end
    if IsDeadTarget() then return true end
    if UnitIsFriend and UnitIsFriend("player", "target") then return true end
    if UnitCanAttack and not UnitCanAttack("player", "target") then return true end
    if UnitIsPlayer and UnitIsPlayer("target") then return true end
    return false
end

local function ApplyForTarget(force)
    if BadTarget() then return end
    local ct = UnitCreatureType("target")
    local spell = ct and TRACK[ct]
    if not spell then return end
    if not force and ct == lastType and TrackingStillOn(spell) then return end
    lastType, lastSpell = ct, spell
    SetTracking(spell)
    return spell
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_TARGET_CHANGED")
ev:SetScript("OnEvent", function()
    if auto then ApplyForTarget(false) end
end)

-- ---------------------------------------------------------------------------
-- Иконка у миникарты
-- ---------------------------------------------------------------------------
local MINIMAP_ICON = "Interface\\AddOns\\HunterTracking\\icon"
local OX, OY = 11, -11

local btn = CreateFrame("Button", "HunterTrackingMinimapButton", Minimap)
btn:SetSize(32, 32)
btn:SetFrameStrata("MEDIUM")

local icon = btn:CreateTexture(nil, "ARTWORK")
icon:SetSize(19, 19)
icon:SetTexture(MINIMAP_ICON)
icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
icon:SetPoint("CENTER", btn, "CENTER", 0, 0)

local border = btn:CreateTexture(nil, "OVERLAY")
border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
border:SetSize(54, 54)
border:SetPoint("CENTER", btn, "CENTER", OX, OY)

btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")

local function UpdatePos(angle)
    local r = 80
    btn:ClearAllPoints()
    btn:SetPoint("CENTER", Minimap, "CENTER",
        math.cos(math.rad(angle)) * r, math.sin(math.rad(angle)) * r)
end

HunterTrackingDB.angle = HunterTrackingDB.angle or 220
UpdatePos(HunterTrackingDB.angle)

btn:SetMovable(true)
btn:RegisterForDrag("LeftButton")
btn:SetScript("OnDragStart", function(self)
    self:SetScript("OnUpdate", function()
        local mx, my = Minimap:GetCenter()
        local cx, cy = GetCursorPosition()
        local scale = Minimap:GetEffectiveScale()
        cx, cy = cx / scale, cy / scale
        local angle = math.deg(math.atan2(cy - my, cx - mx))
        HunterTrackingDB.angle = angle
        UpdatePos(angle)
    end)
end)
btn:SetScript("OnDragStop", function(self)
    self:SetScript("OnUpdate", nil)
end)

btn:SetScript("OnClick", function(self, mouse)
    if mouse == "RightButton" then
        auto = not auto
        HunterTrackingDB.auto = auto
        if not auto then lastType, lastSpell = nil, nil end
        Say("авто-трекинг: " .. (auto and "ВКЛ" or "ВЫКЛ"))
        return
    end
    if BadTarget() then
        Say("цель не подходит (нет / союзник / мёртвая / игрок)")
        return
    end
    local spell = ApplyForTarget(true)
    if spell then
        Say(spell)
    else
        Say("для этого типа нет трекинга")
    end
end)

btn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("Трекинг охотника (HT)")
    GameTooltip:AddLine("Авто: " .. (auto and "ВКЛ" or "ВЫКЛ"), 1, 1, 1)
    GameTooltip:AddLine("ЛКМ — переключить под цель", 0.8, 0.8, 0.8)
    GameTooltip:AddLine("ПКМ — включить/выключить авто", 0.8, 0.8, 0.8)
    GameTooltip:AddLine("Перетащи мышкой — куда хочешь", 0.8, 0.8, 0.8)
    GameTooltip:Show()
end)
btn:SetScript("OnLeave", function() GameTooltip:Hide() end)

SLASH_HUNTERTRACKING1 = "/ht"
SLASH_HUNTERTRACKING2 = "/трекинг"
SlashCmdList["HUNTERTRACKING"] = function(arg)
    arg = string.lower(arg or "")
    if arg == "auto" then
        auto = not auto
        HunterTrackingDB.auto = auto
        if not auto then lastType, lastSpell = nil, nil end
        Say("авто-трекинг: " .. (auto and "ВКЛ" or "ВЫКЛ") .. " (сохранено)")
        return
    end
    if arg == "about" then
        PrintLoad()
        return
    end
    if arg == "diag" then
        local r = UnitReaction and UnitReaction("target", "player")
        Say("тип: " .. tostring(UnitCreatureType("target"))
            .. ", реакция: " .. tostring(r)
            .. ", союзник: " .. tostring(UnitIsFriend and UnitIsFriend("player", "target"))
            .. ", можно атаковать: " .. tostring(UnitCanAttack and UnitCanAttack("player", "target")))
        return
    end
    if BadTarget() then
        Say("цель не подходит (нет / союзник / мёртвая / игрок)")
        return
    end
    local spell = ApplyForTarget(true)
    Say(spell and ("трекинг: " .. spell) or "для этого типа нет трекинга")
end

local ld = CreateFrame("Frame")
ld:RegisterEvent("PLAYER_LOGIN")
ld:SetScript("OnEvent", function(self)
    self:UnregisterEvent("PLAYER_LOGIN")
    PrintLoad()
end)