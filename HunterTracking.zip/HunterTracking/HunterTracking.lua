-- HunterTracking.lua v3.2
local ICON = "Interface\\Icons\\Trade_Engraving"   -- тема "HT"

local TRACK = {
    ["Животное"]   = "Выслеживание животных",
    ["Гуманоид"]   = "Выслеживание гуманоидов",
    ["Нежить"]     = "Выслеживание нежити",
    ["Демон"]      = "Выслеживание демонов",
    ["Элементаль"] = "Выслеживание элементалей",
    ["Дракон"]     = "Выслеживание драконов",
    ["Великан"]    = "Выслеживание великанов",
    ["Скрытый"]    = "Выслеживание скрытого",
}

local function SetTracking(name)
    if type(CastSpellByName) ~= "function" or not name then return false end
    pcall(CastSpellByName, name)
    return true
end

HunterTrackingDB = HunterTrackingDB or {}
if HunterTrackingDB.auto == nil then HunterTrackingDB.auto = false end

local auto = HunterTrackingDB.auto
local lastType, lastSpell = nil, nil

local function TrackingStillOn(spell)
    if not spell or lastSpell ~= spell then return false end
    if type(GetTrackingInfo) == "function" then
        for i = 1, 16 do
            local ok, name, _, _, active = pcall(GetTrackingInfo, i)
            if ok and name and active then return name == spell end
        end
    end
    return true
end

local function IsDeadTarget()
    if UnitIsDead and UnitIsDead("target") then return true end
    if UnitIsGhost and UnitIsGhost("target") then return true end
    if UnitIsCorpse and UnitIsCorpse("target") then return true end
    return false
end

local function ApplyForTarget(force)
    if not UnitExists("target") then return end
    if UnitIsPlayer and UnitIsPlayer("target") then return end
    local ct = UnitCreatureType("target")
    local spell = ct and TRACK[ct]
    if not spell then return end
    if IsDeadTarget() then return end
    if not force and ct == lastType and TrackingStillOn(spell) then return end
    lastType, lastSpell = ct, spell
    SetTracking(spell)
    return spell
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_TARGET_CHANGED")
ev:SetScript("OnEvent", function()
    if auto then ApplyForTarget(false) end
end)

-- ---------------------------------------------------------------------------
-- Иконка «HT» у миникарты
-- ---------------------------------------------------------------------------
local MINIMAP_ICON = "Interface\\AddOns\\HunterTracking\\icon"
local OX, OY = 11, -11   -- смещение золотой рамки

local btn = CreateFrame("Button", "HunterTrackingMinimapButton", Minimap)
btn:SetSize(32, 32)
btn:SetFrameStrata("MEDIUM")

-- картинка внутри круга
local icon = btn:CreateTexture(nil, "ARTWORK")
icon:SetSize(19, 19)
icon:SetTexture(MINIMAP_ICON)
icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
icon:SetPoint("CENTER", btn, "CENTER", 0, 0)

-- золотая рамка
local border = btn:CreateTexture(nil, "OVERLAY")
border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
border:SetSize(54, 54)
border:SetPoint("CENTER", btn, "CENTER", OX, OY)

btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")

local function UpdatePos(angle)
    local r = 80
    local x = math.cos(math.rad(angle)) * r
    local y = math.sin(math.rad(angle)) * r
    btn:ClearAllPoints()
    btn:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

HunterTrackingDB.angle = HunterTrackingDB.angle or 220
UpdatePos(HunterTrackingDB.angle)

btn:SetMovable(true)
btn:RegisterForDrag("LeftButton")
btn:SetScript("OnDragStart", function(self)
    self:SetScript("OnUpdate", function()
        local mx, my = Minimap:GetCenter()
        local cx, cy = GetCursorPosition()
        local scale = Minimap:GetEffectiveScale()
        cx, cy = cx / scale, cy / scale
        local angle = math.deg(math.atan2(cy - my, cx - mx))
        HunterTrackingDB.angle = angle
        UpdatePos(angle)
    end)
end)
btn:SetScript("OnDragStop", function(self)
    self:SetScript("OnUpdate", nil)
end)

btn:SetScript("OnClick", function(self, mouse)
    if mouse == "RightButton" then
        auto = not auto
        HunterTrackingDB.auto = auto
        if not auto then lastType, lastSpell = nil, nil end
        DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99HT|r авто-трекинг: " .. (auto and "ВКЛ" or "ВЫКЛ"))
    else
        local spell = ApplyForTarget(true)
        if spell then
            DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99HT|r " .. spell)
        else
            DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99HT|r цель не подходит")
        end
    end
end)

btn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("Трекинг охотника (HT)")
    GameTooltip:AddLine("Авто: " .. (auto and "ВКЛ" or "ВЫКЛ"), 1, 1, 1)
    GameTooltip:AddLine("ЛКМ — переключить под цель", 0.8, 0.8, 0.8)
    GameTooltip:AddLine("ПКМ — включить/выключить авто", 0.8, 0.8, 0.8)
    GameTooltip:AddLine("Перетащи мышкой — куда хочешь", 0.8, 0.8, 0.8)
    GameTooltip:Show()
end)
btn:SetScript("OnLeave", function() GameTooltip:Hide() end)

SLASH_HUNTERTRACKING1 = "/ht"
SLASH_HUNTERTRACKING2 = "/трекинг"
SlashCmdList["HUNTERTRACKING"] = function(arg)
    arg = string.lower(arg or "")
    if arg == "auto" then
        auto = not auto
        HunterTrackingDB.auto = auto
        if not auto then lastType, lastSpell = nil, nil end
        DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99HT|r авто-трекинг: " .. (auto and "ВКЛ" or "ВЫКЛ") .. " (сохранено)")
        return
    end
    if arg == "diag" then
        DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99HT|r тип цели: " .. tostring(UnitCreatureType("target")))
        return
    end

      if arg == "about" then
        DEFAULT_CHAT_FRAME:AddMessage("|cffffd100HunterTracking|r |cffffffffby|r |cff33ff99SevenKDS|r |cff888888v3.2|r")
        DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99HT|r авто-трекинг: "
            .. (auto and "|cff00ff00ВКЛ|r" or "|cffff3333ВЫКЛ|r")
            .. "  |cff888888— /ht auto|r")
        return
    end
    local spell = ApplyForTarget(true)
    if spell then
        DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99HT|r трекинг: " .. spell)
    else
        DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99HT|r цель не подходит (нет / мертва / игрок)")
    end
end

-- ---------------------------------------------------------------------------
-- Уведомление в чат при загрузке
-- ---------------------------------------------------------------------------
local ADDON_MSG = "|cffffd100HunterTracking|r |cffffffffby|r |cff33ff99SevenKDS|r"

local function PrintLoad()
    DEFAULT_CHAT_FRAME:AddMessage(ADDON_MSG .. " |cff888888v3.2|r")
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99HT|r авто-трекинг: "
        .. (auto and "|cff00ff00ВКЛ|r" or "|cffff3333ВЫКЛ|r")
        .. "  |cff888888— /ht auto|r")
end

local ld = CreateFrame("Frame")
ld:RegisterEvent("PLAYER_LOGIN")
ld:SetScript("OnEvent", function(self)
    self:UnregisterEvent("PLAYER_LOGIN")
    DEFAULT_CHAT_FRAME:AddMessage("|cffffd100HunterTracking|r |cffffffffby|r |cff33ff99SevenKDS|r |cff888888v3.2|r")
end)